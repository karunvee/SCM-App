
SQLITE MANAGEMENT
$ python manage.py dbshell

> (Inside the DB shell)
> DROP TABLE {app-name}_{model-name};